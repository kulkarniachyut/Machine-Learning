import lr
import ridge
import cvridge
import afeature
import bfeature
import brute
import polynomial
import hidto