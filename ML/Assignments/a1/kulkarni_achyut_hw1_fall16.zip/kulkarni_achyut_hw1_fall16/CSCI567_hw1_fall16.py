import Knn_normalise as Knn
import NB as NB

